<html>
<head>
<title>college</title>
</head>
<body bgcolor="silver">
<h1><a href="index.html">Home</a></h1>

<?php
echo"<h1><center>List of College</center><hr></h1>";
echo"1. Dyal Singh collge<br>";
echo"2.  Acharya Narendra Dev Collge <br>";
echo"3.Aditi Mahavidyalay <br>";
echo"4.Aditi Mahavidyalay<br>";
echo"5.Atma Ram Sanatan Dharma College<br>";

echo"6.Bharti collge<br>";
echo"7.collge of Arts<br>";
echo"8.Hindu college<br>";
echo"9.Kikori Mal college<br>";
echo"10. Hans Raj college<br>";
echo"11.Bhim Rao Ambedker college";

?>
</body></html>