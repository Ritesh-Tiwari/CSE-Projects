<html>
<head>
<title>Acadimcs</title>
</head>
<body bgcolor="silver" >
<h1><a href="index.html">Home</a></h1>
<?php
echo"<h1><center>Acadimcs</center></h1><hr><br>";
echo"The University of Delhi is a premier Univrsity of the cuontry width a verebale legacy and interbationala acclaim for highest acadmic standards,diverse educational programes,distinguished faculty,illustrious alumni, varied co-currucular activites and modern in frasstrueture over the many years of its existence, the university has sustained the highest global standards and best practices in higher education <br> <br>";


?>
</body>
</html>