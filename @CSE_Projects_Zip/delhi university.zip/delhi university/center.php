<html>
<head>
<title>Center</title>
</head>
<body bgcolor="silver">
<h1><a href="index.html">Home</a></h1>

<?php
echo"<h1> <center>centers/Institudes</center><hr></h1>";
echo"1. Agriciltural Economics Research center (AERC)<br>";
echo"2. Center for Canadian Studies<br>";
echo"3. Cluster Innovation Center(CIC) <br>";
echo"4. Dr.B.R. Ambedkar Center for Biomedical Research (ACBR)<br>";
echo"5. Center for science Educaton & Communication center<br>";

echo"6.center for Genetic manipulation of Crop Plants<br>";
echo"7.developing countries Research center<br>";
echo"8. Institude of informatics & learning<br>";
echo"9.  Institude of Lifelong learning<br>";
echo"10. Women studies & Development Center <br>";

?>
</body></html>
