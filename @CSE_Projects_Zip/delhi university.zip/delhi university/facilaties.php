<html>
<head>
<title>Facilaties</title>
</head>
<body bgcolor="silver">
<h1><a href="index.html">Home</a></h1>
<?php
echo"<h1><center>Facilaties</center></h1><hr>";
echo"1. Applied Social Science & Humanities<br>";
echo"2. Art<br>";
echo"3. Commerce & Business studies<br>";
echo"4. Education<br>";
echo"5. Law<br>";

echo"6. Interdiscipinary & applied Scinces<br>";
echo"7. Management Studies<br>";
echo"8. Misic & Fine Art<br>";
echo"9. Medical Scinces<br>";
echo"10.Methematical Scince <br>";
echo"11.Technology <br>";
echo"12. Social Scinces<br>";
echo"13. Afffiliated Facilaries <br>";
echo"10. Open Learning <br>";
?>
</body>
</html>