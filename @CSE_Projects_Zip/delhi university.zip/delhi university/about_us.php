<html>
<head>
<title>About us</title>
</head>
<body bgcolor="silver" font-size="20" >
<h1><a href="index.html">Home</a></h1>

<?php
echo"<h1><center>About University of Delhi</center><hr></h1><br>";
echo"The University of Delhi is a premier Univrsity of the cuontry width a verebale legacy and interbationala acclaim for highest acadmic standards,diverse educational programes,distinguished faculty,illustrious alumni, varied co-currucular activites and modern in frasstrueture over the many years of its existence, the university has sustained the highest global standards and best practices in higher education <br> <br>";

echo"\nSir Maurice gwyer, the then vice-chabcellor realizing the importance of a distiguished faculty to act as role model ,relentlessly searched for talent all over the cuontry and roped in men of eminece to this University. Such as prof.D.S.Kothari in Physics prof.T.R.Sheshadri in chemistry , prof. p.Maheswari in botany and prof. M.l.Bhatia in Zoology"; 
?>
</body>
</html>