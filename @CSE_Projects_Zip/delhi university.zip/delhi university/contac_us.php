<html>
<head>
<title> Contac Us</title>
</head>
<body bgcolor="silver" >

<h1><a href="index.html">Home</a></h1>
<?php
echo"<h1><center>Contac us</h1></center><hr>";
echo"Vice Chancellor :Vc@du.ac.in<br>";
echo"Pro-Vice Chancellor:pvc@du.ac.in<br>";
echo"Dean of Collegeas :dean_college@du.ac.in <br>";
echo"Director , South Campus :dir_udsc@du.ac.in<br>";
echo"Registar :registar@du.ac.in<br>";
echo"Controller of Exam: Fax No-91-11-27667336<br>";
?>
</body>
</html>